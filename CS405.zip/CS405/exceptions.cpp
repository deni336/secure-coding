#include <iostream>
#include <stdexcept>  // For std::runtime_error
#include <exception>  // For std::exception
#include <string>

// CustomException class derived from std::exception for custom error handling.
class CustomException : public std::exception {
public:
    // Constructor that accepts a custom error message.
    explicit CustomException(const std::string& message) : message_(message) {}
    
    // Override the what() method to return the custom error message.
    virtual const char* what() const noexcept override {
        return message_.c_str();
    }
private:
    std::string message_;
};

// Function to simulate additional custom logic that throws a standard exception.
bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    
    // Throw a standard exception using std::runtime_error.
    throw std::runtime_error("Standard exception thrown in do_even_more_custom_application_logic");
    
    // Return statement is unreachable due to the throw.
    return true;
}

// Function to simulate custom application logic.
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    // Wrap the call to do_even_more_custom_application_logic in a try-catch block.
    try {
        if(do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch(const std::exception& e) {
        // Catch any standard exception and display its message.
        std::cout << "Caught std::exception in do_custom_application_logic: " << e.what() << std::endl;
    }

    // Throw a custom exception derived from std::exception.
    throw CustomException("Custom exception thrown in do_custom_application_logic");

    // This message will not be printed since the exception above transfers control.
    std::cout << "Leaving Custom Application Logic." << std::endl;
}

// Function to perform division and throw an exception if division by zero is attempted.
float divide(float num, float den)
{
    // Check for a division by zero error.
    if(den == 0)
    {
        // Throw a standard exception for divide by zero.
        throw std::runtime_error("Division by zero error in divide function");
    }
    return (num / den);
}

// Function to demonstrate division with exception handling; declared noexcept.
void do_division() noexcept
{
    // Wrap division call in a try-catch block to handle runtime errors.
    try {
        float numerator = 10.0f;
        float denominator = 0.0f;  // Intentionally set to zero to trigger exception.
  
        float result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch(const std::runtime_error& e) {
        // Catch the runtime_error thrown by divide() and display its message.
        std::cout << "Caught runtime_error in do_division: " << e.what() << std::endl;
    }
}

int main()
{
    // Wrap main logic in a try-catch block with handlers in the specified order.
    try
    {
        std::cout << "Exceptions Tests!" << std::endl;
        
        // Test the division functionality.
        do_division();
        
        // Test the custom application logic functionality.
        do_custom_application_logic();
    }
    // First catch block: handle our custom exception.
    catch(const CustomException& ce) {
        std::cout << "Caught CustomException in main: " << ce.what() << std::endl;
    }
    // Next, catch any other standard exceptions.
    catch(const std::exception& e) {
        std::cout << "Caught std::exception in main: " << e.what() << std::endl;
    }
    // Finally, a catch-all to handle any uncaught exceptions.
    catch(...) {
        std::cout << "Caught an unknown exception in main." << std::endl;
    }
    
    // Keep the console window open after execution
    std::cout << "Press any key to exit..." << std::endl;
    std::cin.get();
    
    return 0;
}
