#include <iostream>
#include <limits>
#include <type_traits>

/// <summary>
/// Template function to safely add numbers while checking for overflow
/// </summary>
template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;
    for (unsigned long int i = 0; i < steps; ++i)
    {
        if (std::numeric_limits<T>::max() - result < increment)
        {
            std::cerr << "Overflow detected! Returning max value." << std::endl;
            return std::numeric_limits<T>::max();
        }
        result += increment;
    }
    return result;
}

/// <summary>
/// Template function to safely subtract numbers while checking for underflow
/// </summary>
template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;
    for (unsigned long int i = 0; i < steps; ++i)
    {
        if (result - std::numeric_limits<T>::lowest() < decrement)
        {
            std::cerr << "Underflow detected! Returning min value." << std::endl;
            return std::numeric_limits<T>::lowest();
        }
        result -= decrement;
    }
    return result;
}

/// <summary>
/// Test function for overflow
/// </summary>
template <typename T>
void test_overflow()
{
    const unsigned long int steps = 5;
    const T increment = std::numeric_limits<T>::max() / steps;
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;

    std::cout << "\tAdding Numbers Without Overflow: ";
    T result = add_numbers<T>(start, increment, steps);
    std::cout << +result << std::endl;

    std::cout << "\tAdding Numbers With Overflow: ";
    result = add_numbers<T>(start, increment, steps + 1);
    std::cout << +result << std::endl;
}

/// <summary>
/// Test function for underflow
/// </summary>
template <typename T>
void test_underflow()
{
    const unsigned long int steps = 5;
    const T decrement = std::numeric_limits<T>::max() / steps;
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;

    std::cout << "\tSubtracting Numbers Without Underflow: ";
    T result = subtract_numbers<T>(start, decrement, steps);
    std::cout << +result << std::endl;

    std::cout << "\tSubtracting Numbers With Underflow: ";
    result = subtract_numbers<T>(start, decrement, steps + 1);
    std::cout << +result << std::endl;
}

int main()
{
    const std::string star_line = std::string(50, '*');
    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    test_overflow<int>();
    test_overflow<unsigned int>();
    test_underflow<int>();
    test_underflow<unsigned int>();
    
    std::cout << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;
    std::cout << "Press Enter to exit...";
    std::cin.get(); // Keeps the console window open
    return 0;
}
